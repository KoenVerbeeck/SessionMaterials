--CREATE DATABASE Test;
DROP TABLE IF EXISTS dbo.JsonTest;
CREATE TABLE dbo.JsonTest
(
     Id             INT IDENTITY(1,1) PRIMARY KEY
    ,CustomerKey    INT
    ,Title          NVARCHAR(8)
    ,FirstName      NVARCHAR(50)
    ,MiddleName     NVARCHAR(50)
    ,LastName       NVARCHAR(50)
    ,Suffix         NVARCHAR(10)
    ,EmailAddress   NVARCHAR(50)
    ,Phone          NVARCHAR(20)
    ,JsonData       JSON
);

INSERT INTO dbo.JsonTest(
     CustomerKey 
    ,Title       
    ,FirstName   
    ,MiddleName  
    ,LastName    
    ,Suffix      
    ,EmailAddress
    ,Phone
    ,JsonData)
SELECT
     CustomerKey 
    ,Title       
    ,FirstName   
    ,MiddleName  
    ,LastName    
    ,Suffix      
    ,EmailAddress
    ,Phone       
    ,(
    SELECT
         CustomerKey    AS [CustomerKey]
        ,Title          AS [Name.Title]
        ,FirstName      AS [Name.FirstName]
        ,MiddleName     AS [Name.MiddleName]
        ,LastName       AS [Name.LastName]
        ,Suffix         AS [Name.Suffix]
        ,EmailAddress   AS [ContactInfo.EmailAddress]
        ,Phone          AS [ContactInfo.Phone]
    FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    ) myjson
FROM AdventureWorksDW2022.dbo.DimCustomer;
GO 100

DROP TABLE IF EXISTS dbo.JsonTest_Index;
CREATE TABLE dbo.JsonTest_Index
(
     Id             INT IDENTITY(1,1) PRIMARY KEY
    ,CustomerKey    INT
    ,Title          NVARCHAR(8)
    ,FirstName      NVARCHAR(50)
    ,MiddleName     NVARCHAR(50)
    ,LastName       NVARCHAR(50)
    ,Suffix         NVARCHAR(10)
    ,EmailAddress   NVARCHAR(50)
    ,Phone          NVARCHAR(20)
    ,JsonData       JSON
);

INSERT INTO dbo.JsonTest_Index(
     CustomerKey 
    ,Title       
    ,FirstName   
    ,MiddleName  
    ,LastName    
    ,Suffix      
    ,EmailAddress
    ,Phone
    ,JsonData)
SELECT
     CustomerKey 
    ,Title       
    ,FirstName   
    ,MiddleName  
    ,LastName    
    ,Suffix      
    ,EmailAddress
    ,Phone       
    ,(
    SELECT
         CustomerKey    AS [CustomerKey]
        ,Title          AS [Name.Title]
        ,FirstName      AS [Name.FirstName]
        ,MiddleName     AS [Name.MiddleName]
        ,LastName       AS [Name.LastName]
        ,Suffix         AS [Name.Suffix]
        ,EmailAddress   AS [ContactInfo.EmailAddress]
        ,Phone          AS [ContactInfo.Phone]
    FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    ) myjson
FROM AdventureWorksDW2022.dbo.DimCustomer;
GO 100

DROP INDEX IF EXISTS ix_json ON dbo.JsonTest_Index;
--CREATE JSON INDEX ix_json ON dbo.JsonTest_Index(JsonData);
CREATE JSON INDEX ix_json ON dbo.JsonTest_Index(JsonData) FOR ('$.Name.FirstName');
--CREATE JSON INDEX ix_json ON dbo.JsonTest_Index(JsonData) FOR ('$.Name.FirstName', '$.ContactInfo.EmailAddress');
CREATE JSON INDEX ix_json ON dbo.JsonTest_Index(JsonData) FOR ('$.Name.FirstName', '$.Name.LastName');
--CREATE JSON INDEX ix_json ON dbo.JsonTest_Index(JsonData) FOR ('$.Name.FirstName', '$.Name'); --> error

SELECT * FROM sys.objects
WHERE [name] LIKE '%json%'


SET STATISTICS IO ON;
--SELECT * FROM dbo.JsonTest
--WHERE JSON_VALUE(JsonData,'$.Name.FirstName') = 'David';

SELECT FirstName, LastName
FROM dbo.JsonTest
WHERE JSON_CONTAINS(JsonData,'David','$.Name.FirstName') = 1;

SELECT FirstName, LastName
FROM dbo.JsonTest_Index
WHERE JSON_VALUE(JsonData,'$.Name.FirstName') = 'David';

SELECT JsonData
FROM dbo.JsonTest_Index
WHERE JSON_CONTAINS(JsonData,'David','$.Name.FirstName') = 1;