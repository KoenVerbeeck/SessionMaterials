USE AdventureWorks2019;

/* create table without PK */
DROP TABLE IF EXISTS Sales.SalesOrderHeader_NoPK 
SELECT *
INTO Sales.SalesOrderHeader_NoPK
FROM Sales.SalesOrderHeader;

SET STATISTICS IO ON;

/* table scan */
SELECT
     SalesOrderID
    ,OrderDate
FROM Sales.SalesOrderHeader_NoPK
WHERE SalesOrderID = 68864;

/* index seek */
SELECT
     SalesOrderID
    ,OrderDate
FROM Sales.SalesOrderHeader
WHERE SalesOrderID = 68864;

/* table scan */
SELECT
     SalesOrderID
    ,OrderDate
FROM Sales.SalesOrderHeader_NoPK
WHERE   SalesOrderID >= 68864
    AND SalesOrderID <= 90000
ORDER BY SalesOrderID;

/* index seek */
SELECT
     SalesOrderID
    ,OrderDate
FROM Sales.SalesOrderHeader
WHERE   SalesOrderID >= 68864
    AND SalesOrderID <= 90000
ORDER BY SalesOrderID;

/* Clean up */
DROP TABLE IF EXISTS Sales.SalesOrderHeader_NoPK 