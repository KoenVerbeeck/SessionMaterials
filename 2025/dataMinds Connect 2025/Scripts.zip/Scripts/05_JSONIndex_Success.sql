USE ChicagoParkingTickets;
--https://sqlsunday.com/2022/12/05/new-demo-database/

/* Code is from the following blog post by Daniel Hutmacher 
https://sqlsunday.com/2025/05/19/json-indexes-first-impressions/
*/

ALTER TABLE Chicago.Buildings ADD JSON_blob json NULL;
 
UPDATE b
SET b.JSON_blob=x.blob
FROM Chicago.Buildings AS b
CROSS APPLY (
    SELECT b.Street AS streetName,
           b.Building_Status AS [status],
           (SELECT JSON_ARRAYAGG(n.[value])
            FROM GENERATE_SERIES(b.From_Address, b.To_Address, CAST(2 AS smallint)) AS n
            ) AS streetAddresses,
           YEAR(b.Build_year) AS buildYear,
           NULLIF(b.Above_ground_stories, 0) AS aboveGroundStories,
           NULLIF(b.Below_ground_stories, 0) AS belowGroundStories,
           NULLIF(b.Number_of_units, 0) AS unitCount
    FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
    ) AS x(blob);

DROP INDEX IF EXISTS IX_JSON ON Chicago.Buildings;
CREATE JSON INDEX IX_JSON
   ON Chicago.Buildings(JSON_blob)
   FOR ('$.streetName', '$.streetAddresses')
   WITH (DATA_COMPRESSION=PAGE);

SELECT COUNT(1)
FROM Chicago.Buildings
WHERE JSON_VALUE(JSON_blob, '$.streetName')             = 'S La Salle St'
  AND JSON_VALUE(JSON_blob, '$.streetAddresses[0]')     <= 209
  AND JSON_VALUE(JSON_blob, '$.streetAddresses[last]')  >= 209;

SELECT COUNT(1)
FROM Chicago.Buildings
WHERE JSON_CONTAINS(JSON_blob, 'S La Salle St', '$.streetName') = 1
  AND JSON_CONTAINS(JSON_blob, 209, '$.streetAddresses[*]')     = 1;