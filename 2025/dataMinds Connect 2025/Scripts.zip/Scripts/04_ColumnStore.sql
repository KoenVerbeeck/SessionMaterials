USE WideWorldImportersDW;

/* Set up */
DROP TABLE IF EXISTS Fact.Order_Big_CCI
CREATE TABLE [Fact].[Order_Big_CCI](
	[Order Key] [BIGINT] NOT NULL,
	[City Key] [INT] NOT NULL,
	[Customer Key] [INT] NOT NULL,
	[Stock Item Key] [INT] NOT NULL,
	[Order Date Key] [DATE] NOT NULL,
	[Picked Date Key] [DATE] NULL,
	[Salesperson Key] [INT] NOT NULL,
	[Picker Key] [INT] NULL,
	[WWI Order ID] [INT] NOT NULL,
	[WWI Backorder ID] [INT] NULL,
	[Description] [NVARCHAR](100) NOT NULL,
	[Package] [NVARCHAR](50) NOT NULL,
	[Quantity] [INT] NOT NULL,
	[Unit Price] [DECIMAL](18, 2) NOT NULL,
	[Tax Rate] [DECIMAL](18, 3) NOT NULL,
	[Total Excluding Tax] [DECIMAL](18, 2) NOT NULL,
	[Tax Amount] [DECIMAL](18, 2) NOT NULL,
	[Total Including Tax] [DECIMAL](18, 2) NOT NULL,
	[Lineage Key] [INT] NOT NULL
) ON [USERDATA]
CREATE CLUSTERED COLUMNSTORE INDEX CCI_Fact_Order_Big ON Fact.Order_Big_CCI
ORDER ([Order Date Key])

DROP TABLE IF EXISTS Fact.Order_Big
CREATE TABLE [Fact].[Order_Big](
	[Order Key] [BIGINT] NOT NULL,
	[City Key] [INT] NOT NULL,
	[Customer Key] [INT] NOT NULL,
	[Stock Item Key] [INT] NOT NULL,
	[Order Date Key] [DATE] NOT NULL,
	[Picked Date Key] [DATE] NULL,
	[Salesperson Key] [INT] NOT NULL,
	[Picker Key] [INT] NULL,
	[WWI Order ID] [INT] NOT NULL,
	[WWI Backorder ID] [INT] NULL,
	[Description] [NVARCHAR](100) NOT NULL,
	[Package] [NVARCHAR](50) NOT NULL,
	[Quantity] [INT] NOT NULL,
	[Unit Price] [DECIMAL](18, 2) NOT NULL,
	[Tax Rate] [DECIMAL](18, 3) NOT NULL,
	[Total Excluding Tax] [DECIMAL](18, 2) NOT NULL,
	[Tax Amount] [DECIMAL](18, 2) NOT NULL,
	[Total Including Tax] [DECIMAL](18, 2) NOT NULL,
	[Lineage Key] [INT] NOT NULL
) ON [USERDATA]
CREATE CLUSTERED INDEX CI_Fact_Order_Big ON Fact.Order_Big([Order Date Key])

/* Insert Data Multiple times
https://sqlkover.com/bigger-fact-table-for-wide-world-importers/
Warning! These queries take some time!
*/
--21:46
INSERT INTO Fact.Order_Big_CCI
(
    [Order Key]
    ,[City Key]
    ,[Customer Key]
    ,[Stock Item Key]
    ,[Order Date Key]
    ,[Picked Date Key]
    ,[Salesperson Key]
    ,[Picker Key]
    ,[WWI Order ID]
    ,[WWI Backorder ID]
    ,Description
    ,Package
    ,Quantity
    ,[Unit Price]
    ,[Tax Rate]
    ,[Total Excluding Tax]
    ,[Tax Amount]
    ,[Total Including Tax]
    ,[Lineage Key]
)
SELECT
     [Order Key] = ISNULL(ROW_NUMBER() OVER(ORDER BY (SELECT NULL)),-1)
    ,[City Key]
    ,[Customer Key]
    ,[Stock Item Key]
    ,[Order Date Key]
    ,[Picked Date Key]
    ,[Salesperson Key]
    ,[Picker Key]
    ,[WWI Order ID]
    ,[WWI Backorder ID]
    ,[Description]
    ,[Package]
    ,[Quantity]
    ,[Unit Price]
    ,[Tax Rate]
    ,[Total Excluding Tax]
    ,[Tax Amount]
    ,[Total Including Tax]
    ,[Lineage Key]
--INTO [Fact].[Order_Big_CCI]
FROM [Fact].[Order]
CROSS JOIN
(SELECT * FROM SYS.columns WHERE object_id < 50) tmp;

--11:11
INSERT INTO Fact.Order_Big
(
    [Order Key]
    ,[City Key]
    ,[Customer Key]
    ,[Stock Item Key]
    ,[Order Date Key]
    ,[Picked Date Key]
    ,[Salesperson Key]
    ,[Picker Key]
    ,[WWI Order ID]
    ,[WWI Backorder ID]
    ,Description
    ,Package
    ,Quantity
    ,[Unit Price]
    ,[Tax Rate]
    ,[Total Excluding Tax]
    ,[Tax Amount]
    ,[Total Including Tax]
    ,[Lineage Key]
)
SELECT
     [Order Key] = ISNULL(ROW_NUMBER() OVER(ORDER BY (SELECT NULL)),-1)
    ,[City Key]
    ,[Customer Key]
    ,[Stock Item Key]
    ,[Order Date Key]
    ,[Picked Date Key]
    ,[Salesperson Key]
    ,[Picker Key]
    ,[WWI Order ID]
    ,[WWI Backorder ID]
    ,[Description]
    ,[Package]
    ,[Quantity]
    ,[Unit Price]
    ,[Tax Rate]
    ,[Total Excluding Tax]
    ,[Tax Amount]
    ,[Total Including Tax]
    ,[Lineage Key]
FROM [Fact].[Order]
CROSS JOIN
(SELECT * FROM SYS.columns WHERE object_id < 50) tmp;

SET STATISTICS IO ON;
SELECT
     [City Key]
    ,SalesAmount = SUM([Total Including Tax])
FROM Fact.Order_Big
WHERE   [Order Date Key] >= '2015-01-01'
    AND [Order Date Key]  < '2016-01-01'
GROUP BY [City Key];

SELECT
     [City Key]
    ,SalesAmount = SUM([Total Including Tax])
FROM Fact.Order_Big_CCI
WHERE   [Order Date Key] >= '2015-01-01'
    AND [Order Date Key]  < '2016-01-01'
GROUP BY [City Key];