USE AdventureWorks2019;

/* Column order matters!
In the following query, the index IX_Person_LastName_FirstName_MiddleName is not used,
because firstname is the second key in the index, not the first.
*/
SELECT BusinessEntityID, LastName, FirstName, Title
FROM Person.Person
WHERE FirstName LIKE 'K%';

/* Covering Index
The index IX_Person_LastName_FirstName_MiddleName is not covering, since it doesn't include Title
*/
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
SELECT BusinessEntityID, LastName, FirstName, Title
FROM Person.Person
WHERE LastName LIKE 'V%';

/* Let's create a covering index */
DROP INDEX IF EXISTS IX_Person_LastName_Covering ON Person.Person;
CREATE NONCLUSTERED INDEX IX_Person_LastName_Covering
    ON Person.Person (LastName ASC)
    INCLUDE(FirstName, Title);

/* Execute the query again */
SELECT BusinessEntityID, LastName, FirstName, Title
FROM Person.Person
WHERE LastName LIKE 'V%';

/* Clean up */
DROP INDEX IF EXISTS IX_Person_LastName_Covering ON Person.Person;

/* Execute the query again to check missing index suggestion */
SELECT BusinessEntityID, LastName, FirstName, Title
FROM Person.Person
WHERE LastName LIKE 'V%';

/* Missing indexes query */
SELECT
     runtime                = CONVERT(VARCHAR(30), GETDATE(), 126)
    ,mig.index_group_handle
    ,mid.index_handle
    ,improvement_measure    = CONVERT(
                                         DECIMAL(28, 1)
                                         ,migs.avg_total_user_cost * migs.avg_user_impact
                                          * (migs.user_seeks + migs.user_scans)
                                     )
    ,create_index_statement = 'CREATE INDEX missing_index_' + CONVERT(VARCHAR, mig.index_group_handle) + '_'
                              + CONVERT(VARCHAR, mid.index_handle) + ' ON ' + mid.statement + ' ('
                              + ISNULL(mid.equality_columns, '') + CASE WHEN mid.equality_columns IS NOT NULL
                                                                            AND mid.inequality_columns IS NOT NULL THEN
                                                                            ','
                                                                       ELSE
                                                                           '' END + ISNULL(mid.inequality_columns, '')
                              + ')' + ISNULL(' INCLUDE (' + mid.included_columns + ')', '')
    ,migs.group_handle
    ,migs.unique_compiles
    ,migs.user_seeks
    ,migs.user_scans
    ,migs.last_user_seek
    ,migs.last_user_scan
    ,migs.avg_total_user_cost
    ,migs.avg_user_impact
    ,migs.system_seeks
    ,migs.system_scans
    ,migs.last_system_seek
    ,migs.last_system_scan
    ,migs.avg_total_system_cost
    ,migs.avg_system_impact
    --,mid.database_id
    --,mid.object_id
FROM sys.dm_db_missing_index_groups      mig
JOIN sys.dm_db_missing_index_group_stats migs ON migs.group_handle = mig.index_group_handle
JOIN sys.dm_db_missing_index_details     mid  ON mig.index_handle  = mid.index_handle
ORDER BY migs.avg_total_user_cost * migs.avg_user_impact * (migs.user_seeks + migs.user_scans) DESC;

/* SARGable queries */
/* SARGable - No functions on key columns */
-- not good
SELECT BusinessEntityID, LastName, FirstName
FROM Person.Person
WHERE LEFT(LastName,1) = 'V';

-- good
SELECT BusinessEntityID, LastName, FirstName
FROM Person.Person
WHERE LastName LIKE 'V%';

DROP INDEX IF EXISTS IX_SalesOrderHeader_OrderDate ON Sales.SalesOrderHeader;
CREATE NONCLUSTERED INDEX IX_SalesOrderHeader_OrderDate ON Sales.SalesOrderHeader(OrderDate)
INCLUDE(SubTotal);

-- not good
SELECT
     OrderMonth = MONTH(OrderDate)
    ,SUM(SubTotal)
FROM Sales.SalesOrderHeader
WHERE   YEAR(OrderDate) = 2012
GROUP BY MONTH(OrderDate);

--  good
SELECT
     OrderMonth = MONTH(OrderDate)
    ,SUM(SubTotal)
FROM Sales.SalesOrderHeader
WHERE   OrderDate >= '2012-01-01'
    AND OrderDate  < '2013-01-01'
GROUP BY MONTH(OrderDate);

-- Clean up
DROP INDEX IF EXISTS IX_SalesOrderHeader_OrderDate ON Sales.SalesOrderHeader;

/* SARGable - No implicit conversions */
SELECT
     [SalesOrderID]     = CONVERT(NVARCHAR(10),[SalesOrderID])
    ,[RevisionNumber]
    ,[OrderDate]
    ,[DueDate]
    ,[ShipDate]
    ,[Status]
    ,[OnlineOrderFlag]
    ,[SalesOrderNumber]
    ,[PurchaseOrderNumber]
    ,[AccountNumber]
    ,[CustomerID]
    ,[SalesPersonID]
    ,[TerritoryID]
    ,[BillToAddressID]
    ,[ShipToAddressID]
    ,[ShipMethodID]
    ,[CreditCardID]
    ,[CreditCardApprovalCode]
    ,[CurrencyRateID]
    ,[SubTotal]
    ,[TaxAmt]
    ,[Freight]
    ,[TotalDue]
    ,[Comment]
    ,[rowguid]
    ,[ModifiedDate]
INTO #SalesOrderHeader
FROM [AdventureWorks2019].[Sales].[SalesOrderHeader];

CREATE CLUSTERED INDEX SH_OrderID ON [#SalesOrderHeader]([SalesOrderID]);

SELECT
     [SalesOrderID]         = CONVERT(VARCHAR(10),[SalesOrderID])
    ,[SalesOrderDetailID]
    ,[CarrierTrackingNumber]
    ,[OrderQty]
    ,[ProductID]
    ,[SpecialOfferID]
    ,[UnitPrice]
    ,[UnitPriceDiscount]
    ,[LineTotal]
    ,[rowguid]
    ,[ModifiedDate]
INTO #SalesOrderDetail
FROM [AdventureWorks2019].[Sales].[SalesOrderDetail];

CREATE CLUSTERED INDEX SD_OrderID_OrderDetailID ON #SalesOrderDetail([SalesOrderID],[SalesOrderDetailID]);

SELECT COUNT(1)
FROM #SalesOrderHeader sh
JOIN #SalesOrderDetail sd ON [sd].[SalesOrderID] = [sh].[SalesOrderID]
WHERE sh.[SalesOrderID] = '43659';

SELECT
     [SalesOrderID]         = CONVERT(NVARCHAR(10),[SalesOrderID])
    ,[SalesOrderDetailID]
    ,[CarrierTrackingNumber]
    ,[OrderQty]
    ,[ProductID]
    ,[SpecialOfferID]
    ,[UnitPrice]
    ,[UnitPriceDiscount]
    ,[LineTotal]
    ,[rowguid]
    ,[ModifiedDate]
INTO #SalesOrderDetail_Correct
FROM [AdventureWorks2019].[Sales].[SalesOrderDetail];

CREATE CLUSTERED INDEX SD_OrderID_OrderDetailID_Correct ON #SalesOrderDetail_Correct([SalesOrderID],[SalesOrderDetailID]);

SELECT COUNT(1)
FROM #SalesOrderHeader sh
JOIN #SalesOrderDetail_Correct sd ON [sd].[SalesOrderID] = [sh].[SalesOrderID]
WHERE sh.[SalesOrderID] = '43659';