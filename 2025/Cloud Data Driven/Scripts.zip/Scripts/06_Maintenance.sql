/*
Index fragmentation
This query can take a while on large databases
*/

SELECT
     SchemaName = dbschemas.[name]
    ,TableName = dbtables.[name]
    ,IndexName = dbindexes.[name]
    ,indexstats.avg_fragmentation_in_percent
    ,indexstats.page_count
FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, 'SAMPLED') indexstats
JOIN sys.tables   dbtables  ON dbtables.object_id       = indexstats.object_id
JOIN sys.schemas  dbschemas ON dbtables.schema_id       = dbschemas.schema_id
JOIN sys.indexes  dbindexes ON  dbindexes.object_id     = indexstats.object_id
                            AND indexstats.index_id     = dbindexes.index_id
WHERE indexstats.database_id = DB_ID()
ORDER BY indexstats.avg_fragmentation_in_percent DESC;

/* Which indexes are used?
Keep in mind counters are reset after server reboot
(this includes scaling in Azure SQL DB)
*/

SELECT
     Table_name  = objects.name
    ,Index_name = indexes.name
    ,user_seeks
    ,user_scans
    ,user_updates
    ,last_user_scan
    ,last_user_seek
FROM sys.dm_db_index_usage_stats
INNER JOIN sys.objects ON dm_db_index_usage_stats.object_id      = objects.object_id
INNER JOIN sys.indexes ON indexes.index_id                       = dm_db_index_usage_stats.index_id
                           AND dm_db_index_usage_stats.object_id = indexes.object_id
WHERE 1 = 1
    --AND is_primary_key = 0 -- This condition excludes primary key constarint
    --AND is_unique    = 0 -- This condition excludes unique key constarint
    --AND user_lookups = 0
    --AND user_seeks   = 0
    --AND user_scans   = 0
ORDER BY user_updates DESC;